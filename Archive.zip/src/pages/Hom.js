import React from 'react'
import Navbar from '../components/NavBar/Navbar'

function Hom() {
  return (
    <div>
   
        <Navbar />
    </div>
  )
}

export default Hom