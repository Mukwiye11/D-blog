import React, { useState } from "react";
import axiosBase from "../api";
function Blog() {
  const [caption, setCaption] = useState();
    
  const createPost = async (data) => {
    
    try {
      const res = await axiosBase.post("/posts", data, {headers: { "x-auth-token": localStorage.getItem("token") },
   
      });
      console.log(res)
    } catch (error) {
      console.error(error);
    }
  };

  const onSubmit = async(e) => {
    e.preventDefault();
    setCaption(e.target.caption.value);
    console.log(e.target.caption.value)

    const postData = {
      caption: e.target.caption.value,
    };
    await createPost(postData);
    setCaption("");
 
  };

  return (
    <div>
      <h1>blog</h1>
      <form action="" onSubmit={(e) => onSubmit(e)}>
        <input type="text" placeholder="caption" name="caption" />
        <button>add</button>
      </form>
      <div>

        
      </div>

    
    </div>
  );
}

export default Blog;
