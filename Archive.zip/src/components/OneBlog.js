import React from "react";
import { Link } from "react-router-dom";

function OneBlog({ post }) {
  return (
    <div>
      <p>{post.caption}</p>
      <Link to={`/blog/${post._id}`}>More</Link>
      <Link to={`/edit/${post._id}`}>Edit</Link>
     
    </div>
  );
}

export default OneBlog;
