import React from 'react'

function footer() {
  return (
    <div>
        <div>
            <h3>About us</h3>
            <p>Let your fans become active supporters of your Creative work</p>
            <p>C</p>

        </div>
        <div>
            <h3>Subscribe</h3>

        </div>
        <div>
            <h3>Follow us</h3>
            <div>

            </div>

        </div>
    </div>
  )
}

export default footer