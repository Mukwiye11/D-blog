import React, { useState, useEffect } from "react";
import axiosBase from "../api";
import OneBlog from "./OneBlog";


function GetBlogs() {
  const [posts, setPosts] = useState();

  useEffect(() => {
    const getPosts = async () => {
      try {
        const res = await axiosBase.get("/posts", {
          headers: { "x-auth-token": localStorage.getItem("token") },
        });
        setPosts(res.data.post);
        console.log(res.data.post);
      } catch (error) {
        console.error(error);
      }
    };
    getPosts();
  }, []);

  return (
    <div>
      <h1>all posts</h1>
      <div>
        {posts ? (
          <div>
            <div>
              {posts.map((post, index) => {
                return <OneBlog key={index} post={post}></OneBlog>;
              })}
            </div>
          </div>
        ) : (
          <h1>Loading ..........</h1>
        )}
      </div>
    </div>
  );
}

export default GetBlogs;
