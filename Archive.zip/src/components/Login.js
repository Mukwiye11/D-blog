import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../api";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [err, setErr] = useState("");
  const onChangeEmail = (e) => {
    setEmail(e.target.value);
  };

  const [password, setPassword] = useState("");
  const onChangePass = (e) => {
    setPassword(e.target.value);
  };
  const loginUser = async (data) => {
    const res = await axios.post("/users/authenticate", data);
    console.log(res.data.content);
    localStorage.setItem("token", res.data.content.token)
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const loginData = {
      email: email,
      password: password,
    };
    setEmail("");
    setPassword("");
    try {
      await loginUser(loginData);
      navigate("/blog");
    } catch (error) {
      setErr(error?.response?.data?.errors || error.message);
    }
  };
  return (
    <form>
      <h1>Login</h1>
      <p>{err}</p>
      <input
        type="email"
        name="email"
        value={email}
        onChange={onChangeEmail}
        placeholder="Email"
      />
      <input
        type="password"
        name="password"
        value={password}
        onChange={onChangePass}
        placeholder="Password"
      />
      <button onClick={(e) => onSubmit(e)}>Submit</button>
    </form>
  );
}
