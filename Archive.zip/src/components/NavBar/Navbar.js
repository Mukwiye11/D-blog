import React, { useState, useEffect } from "react";
import "./Navbar.css";
const Navbar = () => {
  const [menu, setMenu] = useState(false);
  const [screen, setScreen] = useState(window.innerWidth);
  const toggleNav = () => {
    setMenu(!menu);
  };
  useEffect(() => {
    const changeWidth = () => {
      setScreen(window.innerWidth);
    };
    window.addEventListener("resize", changeWidth);
    return () => {
      window.removeEventListener("resize", changeWidth);
    };
  }, []);

  return (
    <nav>
      
     
      {(menu || screen > 500) && (
        <ul className="list">
          <li className="items">Home</li>
          <li className="items">Blog</li>
          <li className="items">Sign up</li>
        </ul>
      )}

      <button onClick={toggleNav} className="btn">
        BTN{" "}
      </button>
    </nav>
  );
};

export default Navbar;
