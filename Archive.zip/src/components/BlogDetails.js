import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axiosBase from "../api";

function BlogDetails() {
  const [blog, setBlog] = useState();
   const { id } = useParams();
 

  console.log(id);
  useEffect(() => {
    const oneBlog = async () => {
      try {
        const res = await axiosBase.get("/posts/" + id, {
          headers: { "x-auth-token": localStorage.getItem("token") },
        });
        console.log(res.data);
        setBlog(res.data.post);
      } catch (error) {
        console.error(error);
      }
    };
    oneBlog();
  }, []);







  

  return (
    <div>
      <h1>blog details</h1>
      {blog ? (
        <div>
          <h2>{blog.caption}</h2>
          <button onClick={editPost}>edit</button>
          
        </div>
      ) : (
        <h1>loading ......</h1>
      )}
     
    </div>
  );
}

export default BlogDetails;
