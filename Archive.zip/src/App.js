import "./App.css";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Hom from "./pages/Hom";
import Signup from "./components/Signup";
import Login from "./components/Login"
import Blog from './components/Blog';
import Users from './components/Users';
import GetBlogs from './components/GetBlogs';
import BlogDetails from './components/BlogDetails';
import EditPost from "./components/EditPost";
function App() {
  return (
    <Router>
    <Routes>
    <Route path="/" element={<Hom/>} />
         <Route path="/sign" element={<Signup/>} />
         <Route path="/login"  element={<Login />} />
         <Route path="/blog"  element={<Blog />} />
         <Route path="/users"  element={<Users />} />
         <Route path="/allblogs"  element={<GetBlogs/>} />
         <Route path="/blog/:id"  element={<BlogDetails/>} />
         <Route path="/edit/:id"  element={<EditPost/>} />
         
         
         
    </Routes>
</Router>

  )
 
}

export default App;
